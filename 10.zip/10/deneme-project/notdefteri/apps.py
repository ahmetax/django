from django.apps import AppConfig


class NotdefteriConfig(AppConfig):
    name = 'notdefteri'
