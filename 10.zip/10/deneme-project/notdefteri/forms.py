from django import forms
from .models import NotDefteri

class NotDefteriForm(forms.ModelForm):
    class Meta:
        model = NotDefteri
        fields = ('ne', 'link', 'resim', 'detay')
        widgets = {
            'detay': forms.Textarea(attrs={'cols': 80, 'rows': 4}),
        }

class NotDefteriForm2(forms.ModelForm):
    ne = forms.CharField(max_length=100, required=False)
    link = forms.URLField(max_length=250, required=False)
    resim = forms.ImageField(required=False)
    detay = forms.CharField(required=False, widget=forms.Textarea(attrs={'cols':80, 'rows':4}))


class NotDefteriFilterForm(forms.ModelForm):
    class Meta:
        model = NotDefteri
        fields = ('ne', 'link', 'detay')
        widgets = {
            'detay': forms.Textarea(attrs={'cols': 80, 'rows': 2}),
        }

