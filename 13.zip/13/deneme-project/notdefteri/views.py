from django.shortcuts import render, HttpResponse, get_object_or_404
from django.shortcuts import HttpResponseRedirect, redirect
from notdefteri.forms import *
from deneme.forms import *
from django.db.models import Q, F
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout, get_user_model

# Create your views here.
MAXSATIR = 2

# User = get_user_model()

def logout_view(request):
    logout(request)
    return redirect("/")

def login_view(request):
    form = LoginForm(request.POST or None)
    context = {
        'form': form
    }
    # print(request.user.is_authenticated)
    if form.is_valid():
        # print(form.cleaned_data)
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/')
        else:
            print("hata var...")
    return render(request, "auth/login.html", context=context)




def home_view(request):
    # return HttpResponse('<h1>views.py dosyasından Merhaba</h1>')
    context = {
        'ad': 'ahmet',
        'soyad': 'aksoy',
        'yaş': 67,
    }
    # return render(request, 'notdefteri/home.html', context=context)
    return render(request, 'home.html', context=context)

def deneme_view(request):
    return HttpResponse('<h2><b>Django deneme_view fonksiyonu</b></h2>')

def ornek_view(request):
    return render(request, 'ornek.html', {'şehirler': ['istanbul', 'ankara', 'adana',
                                                       'izmir', 'samsun'],
                                          'başlık':'Hakiki Örnek başlık'})

def starter_view(request):
    context = {}
    context['ad'] = 'ahmet'
    return render(request,'starter.html', context=context)

@login_required(login_url=login_view)
def notdefteri_detail(request, id):
    notdefteri =get_object_or_404(NotDefteri, id=id)
    context = {
        'notdefteri': notdefteri,
        'header': 'NOTLAR DETAY'
    }
    return render(request, "notdefteri/notdefteri_detail.html", context=context)

@login_required(login_url=login_view)
def notdefteri_create(request):
    form = NotDefteriForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        f = form.save()
        return HttpResponseRedirect(f.get_absolute_url())

    context = {
        'form': form,
    }
    return render(request, 'notdefteri/form.html', context=context)

@login_required(login_url=login_view)
def notdefteri_update(request, id):
    notdefteri = get_object_or_404(NotDefteri,id=id)
    form = NotDefteriForm(request.POST or None, request.FILES or None, instance=notdefteri)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect(notdefteri.get_absolute_url())
    context = {
        'form': form,
    }
    return render(request, 'notdefteri/form.html', context=context)

@login_required(login_url=login_view)
def notdefteri_delete(request, id):
    notdefteri = get_object_or_404(NotDefteri, id=id)
    notdefteri.delete()
    return redirect('notdefteri_listele')

def filtre_uygula(satirlar, form):
    if form['ne'].value():
        if form['ne'].value() > '':
            satirlar = satirlar.filter(ne__icontains=form['ne'].value(),)
    if form['link'].value():
        if form['link'].value() > '':
            satirlar = satirlar.filter(link__icontains=form['link'].value(),)
    if form['detay'].value():
        if form['detay'].value() > '':
            satirlar = satirlar.filter(detay__icontains=form['detay'].value(),)

    return satirlar

@login_required(login_url=login_view)
def notdefteri_listele(request):
    header = 'NOTLAR'
    form = NotDefteriFilterForm(request.GET or None, request.FILES or None)
    # print(form)
    satirlar = NotDefteri.objects.all()
    if request.method == 'GET':
        satirlar = filtre_uygula(satirlar, form)

    print("Satır sayısı= ",len(satirlar))

    # QUERY PART
    query = request.GET.get('q')
    if query:
        print("arama sorgusu yapılıyor")
        satirlar = satirlar.filter(Q(ne__icontains=query) |
                                    Q(link__icontains=query) |
                                    Q(detay__icontains=query)
        ).distinct()

    context = {
        'header': header,
        'satirlar': satirlar,
        'form': form,
    }
    """
    Buraya sayfa kontrol satırları gelecek - paginator
    """
    paginator = Paginator(satirlar, MAXSATIR)
    page_number = request.GET.get('sayfano')
    print("page_number=", page_number)
    try:
        page_obj = paginator.get_page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.get_page(1)
    except EmptyPage:
        page_obj = paginator.get_page(paginator.num_pages)
    return render(request, 'notdefteri/index.html',
                  {'sayfa': page_obj,'form':form,'header':header,'satirlar':satirlar})

    # return render(request, 'notdefteri/index.html', context=context)
