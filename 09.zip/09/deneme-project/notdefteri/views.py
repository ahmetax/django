from django.shortcuts import render, HttpResponse

# Create your views here.

def home_view(request):
    # return HttpResponse('<h1>views.py dosyasından Merhaba</h1>')
    context = {
        'ad': 'ahmet',
        'soyad': 'aksoy',
        'yaş': 67,
    }
    # return render(request, 'notdefteri/home.html', context=context)
    return render(request, 'home.html', context=context)

def deneme_view(request):
    return HttpResponse('<h2><b>Django deneme_view fonksiyonu</b></h2>')

def ornek_view(request):
    return render(request, 'ornek.html', {'şehirler': ['istanbul', 'ankara', 'adana',
                                                       'izmir', 'samsun'],
                                          'başlık':'Hakiki Örnek başlık'})

def starter_view(request):
    context = {}
    context['ad'] = 'ahmet'
    return render(request,'starter.html', context=context)