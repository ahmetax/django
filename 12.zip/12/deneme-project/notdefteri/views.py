from django.shortcuts import render, HttpResponse, get_object_or_404
from django.shortcuts import HttpResponseRedirect, redirect
from .forms import *
from django.db.models import Q, F
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

# Create your views here.
MAXSATIR = 2

def home_view(request):
    # return HttpResponse('<h1>views.py dosyasından Merhaba</h1>')
    context = {
        'ad': 'ahmet',
        'soyad': 'aksoy',
        'yaş': 67,
    }
    # return render(request, 'notdefteri/home.html', context=context)
    return render(request, 'home.html', context=context)

def deneme_view(request):
    return HttpResponse('<h2><b>Django deneme_view fonksiyonu</b></h2>')

def ornek_view(request):
    return render(request, 'ornek.html', {'şehirler': ['istanbul', 'ankara', 'adana',
                                                       'izmir', 'samsun'],
                                          'başlık':'Hakiki Örnek başlık'})

def starter_view(request):
    context = {}
    context['ad'] = 'ahmet'
    return render(request,'starter.html', context=context)

def notdefteri_detail(request, id):
    notdefteri =get_object_or_404(NotDefteri, id=id)
    context = {
        'notdefteri': notdefteri,
        'header': 'NOTLAR DETAY'
    }
    return render(request, "notdefteri/notdefteri_detail.html", context=context)


def notdefteri_create(request):
    form = NotDefteriForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        f = form.save()
        return HttpResponseRedirect(f.get_absolute_url())

    context = {
        'form': form,
    }
    return render(request, 'notdefteri/form.html', context=context)

def notdefteri_update(request, id):
    notdefteri = get_object_or_404(NotDefteri,id=id)
    form = NotDefteriForm(request.POST or None, request.FILES or None, instance=notdefteri)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect(notdefteri.get_absolute_url())
    context = {
        'form': form,
    }
    return render(request, 'notdefteri/form.html', context=context)

def notdefteri_delete(request, id):
    notdefteri = get_object_or_404(NotDefteri, id=id)
    notdefteri.delete()
    return redirect('notdefteri_listele')

def filtre_uygula(satirlar, form):
    if form['ne'].value():
        if form['ne'].value() > '':
            satirlar = satirlar.filter(ne__icontains=form['ne'].value(),)
    if form['link'].value():
        if form['link'].value() > '':
            satirlar = satirlar.filter(link__icontains=form['link'].value(),)
    if form['detay'].value():
        if form['detay'].value() > '':
            satirlar = satirlar.filter(detay__icontains=form['detay'].value(),)

    return satirlar

def notdefteri_listele(request):
    header = 'NOTLAR'
    form = NotDefteriFilterForm(request.GET or None, request.FILES or None)
    # print(form)
    satirlar = NotDefteri.objects.all()
    if request.method == 'GET':
        satirlar = filtre_uygula(satirlar, form)

    print("Satır sayısı= ",len(satirlar))

    # QUERY PART
    query = request.GET.get('q')
    if query:
        print("arama sorgusu yapılıyor")
        satirlar = satirlar.filter(Q(ne__icontains=query) |
                                    Q(link__icontains=query) |
                                    Q(detay__icontains=query)
        ).distinct()

    context = {
        'header': header,
        'satirlar': satirlar,
        'form': form,
    }
    """
    Buraya sayfa kontrol satırları gelecek - paginator
    """
    paginator = Paginator(satirlar, MAXSATIR)
    page_number = request.GET.get('sayfano')
    print("page_number=", page_number)
    try:
        page_obj = paginator.get_page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.get_page(1)
    except EmptyPage:
        page_obj = paginator.get_page(paginator.num_pages)
    return render(request, 'notdefteri/index.html',
                  {'sayfa': page_obj,'form':form,'header':header,'satirlar':satirlar})

    # return render(request, 'notdefteri/index.html', context=context)