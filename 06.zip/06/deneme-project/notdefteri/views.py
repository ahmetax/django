from django.shortcuts import render, HttpResponse

# Create your views here.

def home_view(request):
    # return HttpResponse('<h1>views.py dosyasından Merhaba</h1>')
    context = {
        'ad': 'ahmet',
        'soyad': 'aksoy',
        'yaş': 67,
    }
    return render(request, 'notdefteri/home.html', context=context)

def deneme_view(request):
    return HttpResponse('<h2><b>Django deneme_view fonksiyonu</b></h2>')