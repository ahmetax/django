from django.contrib import admin
from .models import NotDefteri

# Register your models here.
admin.site.register(NotDefteri)

