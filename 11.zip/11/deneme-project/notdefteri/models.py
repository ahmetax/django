from django.db import models
from django.urls import reverse

# Create your models here.
class NotDefteri(models.Model):
    ne = models.CharField(max_length=100, verbose_name='Ne', blank=True)
    ilktar = models.DateTimeField(verbose_name='İlk Tar', auto_now_add=True)
    sontar = models.DateTimeField(verbose_name='Son Tar', auto_now=True)
    link = models.URLField(max_length=250, verbose_name='Link', null=True, blank=True)
    resim = models.ImageField(upload_to='images/', verbose_name='Resim', null=True, blank=True)
    detay = models.TextField(verbose_name='Detay', null=True, blank=True)

    def __str__(self):
        return(f'{self.ilktar}-{self.ne}')

    def get_absolute_url(self):
        return reverse('notdefteri_detail', args=[str(self.id)])
